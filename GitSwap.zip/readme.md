Git EasySwap: an alternative tool for interactive rebases
=========================================================

This tool aims to replace "git rebase --interactive": it helps you keep your history clean.
- Split, merge and reword your commits.
- When reordering your commits, detect and solve conflicts at the best moment, when it is easy.

**Disclaimer**: This tool is in an early stage of development.  
All the core functionalities are present, and you will be able to roll back any modifications.  
However, you may experience slowdowns, occasional crashes and incompatibilities with your environment.  
I encourage to try it and to see if it works in your setup and suits your needs.

Who could be interested ?
-------------------------
Any developer using the "git rebase --interactive" command from time to time, in order to share a "clean" history (before a Merge Request for instance).

How to use
----------
Get Git, Python 3 with PyQt5, and run EasySwap.py. 

More options coming soon.

---

[User manual](Doc/user_manual.md)

[Developer's notes, Planned features and Known bugs](Doc/technical_notes.md)