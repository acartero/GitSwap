from collections import OrderedDict
from enum import Enum
from typing import List, Iterator, Generator


class Source(Enum):
    LEFT = "left"
    RIGHT = "right"


class LineType(Enum):
    CONTEXT = " "
    NO_ENDLINE_CONTEXT = "\\"
    ADDITION = "+"
    DELETION = "-"
    ADD_DEL = "+-"


def join(enumerable):
    return "".join([str(e) for e in enumerable])


def nformat(elt):
    if elt is None:
        return ""
    else:
        return str(elt) + "\n"


class Line:
    def __init__(self, line_type: LineType, content: str, no_new_line):
        self.type = line_type
        self.content = content.rstrip("\n").rstrip("\r")
        self.no_new_line = no_new_line

    def __str__(self):
        if self.no_new_line:
            return self.type.value + self.content + "\n" + "\\ No newline at end of file"
        else:
            return self.type.value + self.content

    def is_addition(self):
        return self.type == LineType.ADDITION

    def is_deletion(self):
        return self.type == LineType.DELETION

    def is_context(self):
        return self.type == LineType.CONTEXT or self.type == LineType.NO_ENDLINE_CONTEXT


class Stats:
    def __init__(self, deletion_start_line: int, deletion_size: int, addition_start_line: int, addition_size: int):
        self.deletion_start_line = deletion_start_line
        self.deletionSize = deletion_size
        self.addition_start_line = addition_start_line
        self.additionSize = addition_size

    def __str__(self):
        ret = "@@ -" + str(self.deletion_start_line)
        if self.deletionSize != -1:
            ret += "," + str(self.deletionSize)
        ret += " +" + str(self.addition_start_line)
        if self.additionSize != -1:
            ret += "," + str(self.additionSize)
        return ret + " @@" + "\n"


class Hunk:
    def __init__(self, lines: List[Line], stats: Stats):
        self.lines = lines
        self.stats = stats

    def __str__(self):
        return str(self.stats) + "\n".join(str(l) for l in self.lines) + "\n"


class Metadata:
    def __init__(self, diff, deleted_file, new_file, index, similarity, minus, plus, rename_from, rename_to):
        self.diff = diff
        self.deleted_file = deleted_file
        self.new_file = new_file
        self.index = index
        self.similarity = similarity
        self.minus = minus
        self.plus = plus
        self.rename_from = rename_from
        self.rename_to = rename_to

    def is_trivial(self):  # returns False if there are elements which wont be dealt with in v0.1
        return self.deleted_file is None \
               and self.new_file is None \
               and self.index is None \
               and self.similarity is None \
               and self.rename_from is None \
               and self.rename_to is None

    def __str__(self):
        ret = self.diff + "\n"
        ret += nformat(self.deleted_file)
        ret += nformat(self.new_file)
        ret += nformat(self.index)
        ret += nformat(self.similarity)
        ret += nformat(self.minus)
        ret += nformat(self.plus)
        ret += nformat(self.rename_from)
        ret += nformat(self.rename_to)

        return ret


class FileDiff:
    def __init__(self, hunks: List[Hunk], metadata: Metadata):
        self.hunks = hunks
        self.metadata = metadata

    def __str__(self):
        if len(self.hunks) == 1:
            if self.hunks[0].stats.addition_start_line == 0 and self.hunks[0].stats.additionSize == 0:
                self.metadata.plus = "+++ /dev/null"
            if self.hunks[0].stats.deletion_start_line == 0 and self.hunks[0].stats.deletionSize == 0:
                self.metadata.minus = "--- /dev/null"
        return str(self.metadata) + join(self.hunks)


class GitDiff:
    def __init__(self, file_diffs: List[FileDiff], git_hash, message):
        self.hash = git_hash
        self.message = message
        self.file_diffs: OrderedDict[str, FileDiff] = OrderedDict()
        for file_diff in file_diffs:
            if file_diff.metadata.plus != "+++ /dev/null":
                self.file_diffs[file_diff.metadata.plus.lstrip("+++ b/")] = file_diff
            else:
                self.file_diffs[file_diff.metadata.minus.lstrip("--- a/")] = file_diff

    def __str__(self):
        return join(self.file_diffs.values())
